// Package aws allows to interact with resources on Amazon Web Services.
package aws
