---
name: Enhancement proposal
about: Propose an enhancement for this project
labels: 'enhancement'
---
# Summary

What change needs making?

# Use Cases

When would you use this?

---
<!-- Issue Author: Don't delete this message to encourage other users to support your issue! -->
**Message from the maintainers**:

Impacted by this bug? Give it a 👍. We prioritize the issues with the most 👍.