#!/bin/bash

# Copyright 2022 Google LLC.
# Use of this source code is governed by a BSD-style
# license that can be found in the LICENSE file.

go run cmd/test_signer.go testdata/rsa2048bit.pem
